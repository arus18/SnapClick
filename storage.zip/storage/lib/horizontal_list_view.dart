import 'dart:io';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
import 'package:storage/home.dart';
import 'package:storage/imageView.dart';
import 'package:storage/imitate.dart';
import 'package:storage/profile_view.dart';
import 'package:storage/view_all.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';

class HorizontalListView extends StatelessWidget {
  final CollectionReference imitations;
  final String postID;
  final String originalImg1Url;
  final String originalImg2Url;
  final String originalImg3Url;
  final String originalImg4Url;
  final numberOfImitations;
  final FirebaseUser _user;
  final String userIDwhoCreatedThisGrid;
  final String displayName;
  final String profilePhotoUrl;
  final bool isGoogleUserSignedIn;
  final bool forProfileView;

  HorizontalListView(
      this.imitations,
      this.postID,
      this.originalImg1Url,
      this.originalImg2Url,
      this.originalImg3Url,
      this.originalImg4Url,
      this.numberOfImitations,
      this._user,
      this.userIDwhoCreatedThisGrid,
      this.displayName,
      this.profilePhotoUrl,
      this.isGoogleUserSignedIn,
      {this.forProfileView: false});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: imitations
          .orderBy('timestamp', descending: true)
          .limit(5)
          .snapshots(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        final List<Grid> gridList = new List<Grid>();
        if (snapshot.hasError) {
          return Center(child: Text('${snapshot.error}'));
        } else if (snapshot.connectionState == ConnectionState.waiting) {
          return LoadingGrid();
        } else {
          if (forProfileView) {
            gridList.insert(
                0,
                Grid(
                  postID,
                  originalImg1Url,
                  originalImg2Url,
                  originalImg3Url,
                  originalImg4Url,
                  _user,
                  userIDwhoCreatedThisGrid,
                  displayName,
                  profilePhotoUrl,
                  isGoogleUserSignedIn,
                  numberOfImitations: numberOfImitations,
                  forProfileView: true,
                ));
          } else {
            gridList.insert(
                0,
                Grid(
                  postID,
                  originalImg1Url,
                  originalImg2Url,
                  originalImg3Url,
                  originalImg4Url,
                  _user,
                  userIDwhoCreatedThisGrid,
                  displayName,
                  profilePhotoUrl,
                  isGoogleUserSignedIn,
                  isOriginalImg: true,
                  numberOfImitations: numberOfImitations,
                ));
          }
          if (snapshot.hasData) {
            snapshot.data.documents.forEach((imitation) {
              gridList.add(Grid(
                postID,
                imitation['imitationImg1'],
                imitation['imitationImg2'],
                imitation['imitationImg3'],
                imitation['imitationImg4'],
                _user,
                imitation['userIDwhoCreatedThisGrid'],
                imitation['displayName'],
                imitation['profilePhotoUrl'],
                isGoogleUserSignedIn,
              ));
            });
          }
          if (snapshot.data.documents.length == 5) {
            gridList.add(Grid(
              postID,
              originalImg1Url,
              originalImg2Url,
              originalImg3Url,
              originalImg4Url,
              _user,
              userIDwhoCreatedThisGrid,
              displayName,
              profilePhotoUrl,
              isGoogleUserSignedIn,
              numberOfImitations: numberOfImitations,
              withViewAll: true,
            ));
          }
        }
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: gridList,
          ),
        );
      },
    );
  }
}

class Grid extends StatefulWidget {
  final String postID;
  final String img1Url;
  final String img2Url;
  final String img3Url;
  final String img4Url;
  final numberOfImitations;
  final bool isOriginalImg;
  final FirebaseUser _user;
  final String userIDwhoCreatedThisGrid;
  final String displayName;
  final String profilePhotoUrl;
  final bool withViewAll;
  final bool isGoogleUserSignedIn;
  final bool forProfileView;

  Grid(
      this.postID,
      this.img1Url,
      this.img2Url,
      this.img3Url,
      this.img4Url,
      this._user,
      this.userIDwhoCreatedThisGrid,
      this.displayName,
      this.profilePhotoUrl,
      this.isGoogleUserSignedIn,
      {this.isOriginalImg: false,
      this.withViewAll: false,
      this.numberOfImitations,
      this.forProfileView: false});
  @override
  State<StatefulWidget> createState() {
    return GridState(
        postID,
        img1Url,
        img2Url,
        img3Url,
        img4Url,
        _user,
        userIDwhoCreatedThisGrid,
        displayName,
        profilePhotoUrl,
        isGoogleUserSignedIn,
        isOriginalImg: isOriginalImg,
        withViewAll: withViewAll,
        numberOfImitations: numberOfImitations,
        forProfileView: forProfileView);
  }
}

class GridState extends State<Grid> {
  final String postID;
  final String img1Url;
  final String img2Url;
  final String img3Url;
  final String img4Url;
  final numberOfImitations;
  final bool isOriginalImg;
  final bool withViewAll;
  final FirebaseUser _user;
  final String userIDwhoCreatedThisGrid;
  final String displayName;
  final String profilePhotoUrl;
  final bool forProfileView;
  bool isDownloadComplete = false;
  bool networkError = false;
  final bool isGoogleUserSignedIn;
  List<Image> images = List<Image>();
  List<Image> imagesForImageView = List<Image>();
  Image profilePhoto;
  bool removeInOriginalClicked = false;
  final CollectionReference users = Firestore.instance.collection('users');
  final CollectionReference imitations =
      Firestore.instance.collection('imitations');
  final CollectionReference posts = Firestore.instance.collection('posts');

  @override
  initState() {
    super.initState();
    downloadImages();
  }

  downloadImages() async {
    try {
      profilePhoto = Image.file(
          await DefaultCacheManager().getSingleFile(profilePhotoUrl));
      final img1 = await imageWithFit(
          (await DefaultCacheManager().getSingleFile(img1Url)));
      final img2 = await imageWithFit(
          (await DefaultCacheManager().getSingleFile(img2Url)));
      final img3 = await imageWithFit(
          (await DefaultCacheManager().getSingleFile(img3Url)));
      final img4 = await imageWithFit(
          (await DefaultCacheManager().getSingleFile(img4Url)));
      images.add(img1);
      images.add(img2);
      images.add(img3);
      images.add(img4);
      if (mounted) {
        setState(() {
          isDownloadComplete = true;
        });
      }
    } catch (err) {
      networkError = true;
    }
  }

  Future<Image> imageWithFit(File imgFile) async {
    imagesForImageView.add(Image.file(imgFile));
    ImageProperties properties =
        await FlutterNativeImage.getImageProperties(imgFile.path);
    if (properties.width > properties.height) {
      return Image.file(
        imgFile,
        fit: BoxFit.fitHeight,
      );
    }
    return Image.file(
      imgFile,
      fit: BoxFit.fitWidth,
    );
  }

  GridState(
      this.postID,
      this.img1Url,
      this.img2Url,
      this.img3Url,
      this.img4Url,
      this._user,
      this.userIDwhoCreatedThisGrid,
      this.displayName,
      this.profilePhotoUrl,
      this.isGoogleUserSignedIn,
      {this.isOriginalImg: false,
      this.withViewAll: false,
      this.numberOfImitations,
      this.forProfileView: false});

  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);
    final width = query.orientation == Orientation.portrait
        ? query.size.width
        : query.size.height;
    return isDownloadComplete
        ? networkError
            ? LoadingGrid(
                networkErr: true,
              )
            : SizedBox(
                width: width - 50,
                child: Column(
                  crossAxisAlignment: withViewAll
                      ? CrossAxisAlignment.end
                      : CrossAxisAlignment.start,
                  children: <Widget>[
                    Card(
                      child: GestureDetector(
                          onTap: () {
                            if (!forProfileView) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => ProfileView(
                                          isGoogleUserSignedIn,
                                          _user,
                                          userIDwhoCreatedThisGrid,
                                          displayName)));
                            }
                          },
                          child: rowForCard()),
                    ),
                    GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      ImageView(imagesForImageView)));
                        },
                        child: GridView.count(
                          padding: EdgeInsets.all(1),
                          mainAxisSpacing: 1,
                          crossAxisSpacing: 1,
                          shrinkWrap: true,
                          physics: ScrollPhysics(),
                          crossAxisCount: 2,
                          children: images,
                        )),
                    (isOriginalImg && (_user.uid != userIDwhoCreatedThisGrid) ||
                            forProfileView &&
                                (_user.uid != userIDwhoCreatedThisGrid))
                        ? SizedBox(
                            height: 30,
                            child: FloatingActionButton.extended(
                                shape: RoundedRectangleBorder(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(10))),
                                heroTag: 'imitateBtnfor' + postID,
                                backgroundColor: Colors.deepOrangeAccent,
                                label: Center(
                                    child: Text('Imitate',
                                        style: TextStyle(color: Colors.black))),
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              CameraPreviewToImitate(
                                                  Home.bottombar.currentState,
                                                  images,
                                                  postID,
                                                  userIDwhoCreatedThisGrid,
                                                  _user,
                                                  displayName,
                                                  profilePhotoUrl,
                                                  isGoogleUserSignedIn)));
                                }))
                        : withViewAll
                            ? SizedBox(
                                height: 30,
                                child: FloatingActionButton.extended(
                                    heroTag: 'viewAllBtnfor' + postID,
                                    shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10))),
                                    backgroundColor: Colors.deepOrangeAccent,
                                    label: Text('View all',
                                        style: TextStyle(color: Colors.black)),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => ViewAll(
                                                  postID,
                                                  _user,
                                                  userIDwhoCreatedThisGrid,
                                                  displayName,
                                                  profilePhotoUrl,
                                                  img1Url,
                                                  img2Url,
                                                  img3Url,
                                                  img4Url,
                                                  isGoogleUserSignedIn)));
                                    }))
                            : SizedBox(
                                height: 30,
                                child: MaterialButton(
                                  onPressed: () {},
                                ))
                  ],
                ))
        : LoadingGrid();
  }

  Widget rowForCard() {
    if (isOriginalImg) {
      return RowForOriginalImg(profilePhoto, displayName, numberOfImitations);
    } else if (forProfileView && (_user.uid == userIDwhoCreatedThisGrid)) {
      return RowForProfileView(
        numberOfImitations,
        withRemoveButton: true,
        postID: postID,
        userID: _user.uid,
      );
    } else if (forProfileView) {
      return RowForProfileView(numberOfImitations);
    } else {
      return RowForImitateImage(profilePhoto, displayName);
    }
  }
}

class LoadingGrid extends StatelessWidget {
  final bool networkErr;
  LoadingGrid({this.networkErr: false});
  @override
  Widget build(BuildContext context) {
    final query = MediaQuery.of(context);
    double width = query.size.width;
    if (query.orientation == Orientation.landscape) {
      width = query.size.height;
    }
    return Column(children: <Widget>[
      SizedBox(
        height: 50,
      ),
      SizedBox(
          width: width - 50,
          child: GridView.count(
            crossAxisSpacing: 1,
            mainAxisSpacing: 1,
            shrinkWrap: true,
            physics: ScrollPhysics(),
            crossAxisCount: 2,
            children: <Widget>[
              LoadingBox(
                networkErr: networkErr,
              ),
              LoadingBox(
                networkErr: networkErr,
              ),
              LoadingBox(
                networkErr: networkErr,
              ),
              LoadingBox(
                networkErr: networkErr,
              )
            ],
          )),
      SizedBox(
          height: 30,
          child: MaterialButton(
            onPressed: () {},
          ))
    ]);
  }
}

class LoadingBox extends StatelessWidget {
  final bool networkErr;
  LoadingBox({this.networkErr: false});
  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.grey,
        child: Center(
          child: Text(networkErr ? 'Network err' : 'Loading'),
        ));
  }
}

class RowForOriginalImg extends StatelessWidget {
  final Image profilePhoto;
  final String displayName;
  final numberOfImitations;
  RowForOriginalImg(
      this.profilePhoto, this.displayName, this.numberOfImitations);
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        SizedBox(height: 50, child: profilePhoto),
        Text(displayName,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        Column(
          children: <Widget>[Text('$numberOfImitations'), Text('imitations  ')],
        )
      ],
    );
  }
}

class RowForImitateImage extends StatelessWidget {
  final Image profilePhoto;
  final String displayName;

  RowForImitateImage(this.profilePhoto, this.displayName);
  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        SizedBox(height: 50, child: profilePhoto),
        SizedBox(
          width: 10,
        ),
        Text(displayName,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
      ],
    );
  }
}

class RowForProfileView extends StatelessWidget {
  final numberOfImitations;
  final bool withRemoveButton;
  final String postID;
  final String userID;
  final CollectionReference users = Firestore.instance.collection('users');
  final CollectionReference imitations =
      Firestore.instance.collection('imitations');
  final CollectionReference posts = Firestore.instance.collection('posts');
  RowForProfileView(this.numberOfImitations,
      {this.withRemoveButton: false, this.postID, this.userID});
  @override
  Widget build(BuildContext context) {
    return withRemoveButton
        ? Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Text(
                    '  $numberOfImitations',
                    style: TextStyle(fontSize: 20),
                  ),
                  SizedBox(
                    height: 50,
                    width: 10,
                  ),
                  Text('imitations', style: TextStyle(fontSize: 20))
                ],
              ),
              IconButton(
                color: Colors.red,
                icon: Icon(Icons.remove_circle_outline),
                onPressed: () {
                  posts.document(postID).delete();
                  imitations.document(postID).delete();
                  users
                      .document(userID)
                      .collection('posts')
                      .document(postID)
                      .delete();
                },
              )
            ],
          )
        : Row(
            children: <Widget>[
              Text(
                '  $numberOfImitations',
                style: TextStyle(fontSize: 20),
              ),
              SizedBox(
                height: 50,
                width: 10,
              ),
              Text('imitations', style: TextStyle(fontSize: 20))
            ],
          );
  }
}
