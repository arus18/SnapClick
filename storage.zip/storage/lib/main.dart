import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:storage/signin.dart';

void main() {
  ErrorWidget.builder = (FlutterErrorDetails details) => Material(
          child: Center(
        child: Text(
          '$details',
          style: TextStyle(fontSize: 20),
        ),
      ));
  runApp(MaterialApp(
    home: StartUpScreen(),
  ));
}
