import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:storage/horizontal_list_view.dart';

class ViewAll extends StatelessWidget {
  
  final String postID;
  final FirebaseUser user;
  final String userIDwhoCreatedThisGrid;
  final String displayName;
  final String profilePhotoUrl;
  final String originalImg1;
  final String originalImg2;
  final String originalImg3;
  final String originalImg4;
  final bool isGoogleUserSignedIn;
  ViewAll(
    
      this.postID,
      this.user,
      this.userIDwhoCreatedThisGrid,
      this.displayName,
      this.profilePhotoUrl,
      this.originalImg1,
      this.originalImg2,
      this.originalImg3,
      this.originalImg4,
      this.isGoogleUserSignedIn);
  final CollectionReference imitations =
      Firestore.instance.collection('imitations');
  @override
  Widget build(BuildContext context) {
    final allImitations = imitations.document(postID).collection('imitations');
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.deepOrangeAccent,
          title: Text('All imitations'),
        ),
        body: StreamBuilder<QuerySnapshot>(
            stream: allImitations.snapshots(),
            builder:
                (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
              if (snapshot.hasError) {
                return Center(child: Text('${snapshot.error}'));
              } else if (snapshot.connectionState == ConnectionState.waiting) {
                return Center(
                  child: Text('Loading'),
                );
              } else {
                final List<Grid> gridList = new List<Grid>();
                gridList.insert(
                    0,
                    Grid(
                     
                        postID,
                        originalImg1,
                        originalImg2,
                        originalImg3,
                        originalImg4,
                        user,
                        userIDwhoCreatedThisGrid,
                        displayName,
                        profilePhotoUrl,
                        isGoogleUserSignedIn));

                if (snapshot.hasData) {
                  snapshot.data.documents.forEach((imitation) {
                    gridList.add(Grid(
                     
                        postID,
                        imitation['imitationImg1'],
                        imitation['imitationImg2'],
                        imitation['imitationImg3'],
                        imitation['imitationImg4'],
                        user,
                        imitation['userIDwhoCreatedThisGrid'],
                        imitation['displayName'],
                        imitation['profilePhotoUrl'],
                        isGoogleUserSignedIn));
                  });
                }
                return ListView.builder(
                  itemCount: gridList.length,
                  itemBuilder: (context, index) => gridList[index],
                );
              }
            }));
  }
}
